# Load a text file as a list.

"""Arguments:
- Text file name (and directory path, if needed)

Exceptions:
- IOError if filename not found

Returns:
- A list of all words in a text (.txt) file in lower case

Requires import sys

"""

import sys


def load(file):
    #  Open a text (.txt) file and return a list of lowercase strings, this is, words
    try:
        with open(file) as in_file:  # If no issues found, load the text file as list of strings
            loaded_txt = in_file.read().strip().split("\n")  # the text file’s whitespace is removed,
            # and its items are split into separate lines and added to a list
            loaded_txt = [x.lower() for x in loaded_txt]  # Convert all words to lowercase
            return loaded_txt
    except IOError as e:  # If I/O Error is found,the program shows this error
        print("{}\nError opening {}. Terminating program.".format(e, file), file=sys.stderr)
        sys.exit(1)  # If any other error is found, it will show standard "error 1"
