# Find palindromes (letter palingrams) in a dictionary file.
# It identifies which words are palindromes, saves them to a list, and prints the list as stacked items.

import Load_Dictionary  # Imports the function we created to load a dictionary

word_list = Load_Dictionary.load("2of4brif.txt")  # Creates the list of words from the dictionary

pali_list = []  # Creates an empty list of the panlindromes the program will find

for word in word_list:
    if len(word) > 1 and word == word[::-1]:  # If the word has more than 1 letter AND it reads the same way
        # forth and back then...
        pali_list.append(word)  # ...add the word to the list

print(*pali_list, sep="\n")  # Print the palindromes stacked without commas or quotes.
# This is done using the "*" and the separator "\n" which says one word per line
print("\nNumber of palindromes found = {}".format(len(pali_list)))
print("Number of words in the dictionary = {}".format(len(word_list)))
print("% of palindromes found: ", (len(pali_list)/len(word_list))*100,"%")