# Find all wordpair palingrams in a dictionary file.

import Load_Dictionary
word_list = Load_Dictionary.load('2of4brif.txt')

pali_list = []  # Empty list of palingrams

def find_palingrams():  # Function to find word-pair palingrams
    for word in word_list:
        end = len(word)
        rev_word = word[::-1]
        if end > 1:
            for i in range(end):
                if word[i:] == rev_word[:end-i] and rev_word[end-i:] in word_list:
                    pali_list.append((word, rev_word[end-i:]))
                if word[:i] == rev_word[end-i:] and rev_word[:end-i] in word_list:
                    pali_list.append((rev_word[:end-i], word))
    return pali_list

palingrams = find_palingrams()

# Sort palingrams on first word

sorted_palingrams = sorted(palingrams)

# Show list of palingrams

for first, second in sorted_palingrams:
    print("{} {}".format(first, second))

print("\nNumber of palingrams = {}\n".format(len(sorted_palingrams)))
