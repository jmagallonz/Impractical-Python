# cProfile checks profile of a program
# A profile is a measurement output—a record of how long and how often parts of a program are executed

import cProfile
import palingrams_optimized
cProfile.run("palingrams_optimized.find_palingrams()")